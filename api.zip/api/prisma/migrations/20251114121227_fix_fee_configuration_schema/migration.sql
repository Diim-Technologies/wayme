-- AlterTable
ALTER TABLE `fee_configurations` MODIFY `applicableTo` VARCHAR(191) NULL;
